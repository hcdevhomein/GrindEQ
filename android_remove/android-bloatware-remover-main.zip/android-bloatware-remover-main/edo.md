## How to enable Developer options and USB Debugging?
1. Open **Settings** in your device. <br>
2. Go to **System/About/Device Info** (this setting vary with different manufacturers). <br>
3. Tap **Build number** or **Version Number** 7 times. This will enable developer options.<br>
4. Find developer option under the **About/Advance Settings/Additional Settings**...
5. Open **Developer Options**. <br>
6. Enable **USB Debugging**.
